﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MasterMind
{
    class AttemptResult
    {
        public int redPegs { get; set; }
        public int whitePegs { get; set; }
    }
}
